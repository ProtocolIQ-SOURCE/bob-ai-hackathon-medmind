# Presentation Slide Deck

This directory contains the pitch and architecture slides for **TrialGuard** submitted to the **Bob AI Hackathon** (AI Track).

## Slide Decks

- **[`slides.pdf`](slides.pdf)**: Portable slide deck formatted in landscape aspect ratio (recommended for review).
- **[`slides.pptx`](slides.pptx)**: Editable PowerPoint slide deck.

## Slide Structure

1. **Title Slide**: Project Name, Tagline, Team (MedMinds), Track (AI).
2. **Slide 1 — Problem**: Who experiences protocol deviation blindness, why it happens, and quantified impact.
3. **Slide 2 — Solution**: Deterministic protocol rule engine, 4-dimensional explainable 0–100 risk scoring, and human-in-the-loop quality.
4. **Slide 3 — Demo & Architecture**: System architecture, component relationships, verifiable audit trail, and live visit simulation.
5. **Slide 4 — IBM Technology Integration**: Load-bearing IBM Bob integration via Model Context Protocol (MCP) and responsible AI boundary.
6. **Slide 5 — Impact & Vision**: Operational time savings, audit readiness (21 CFR Part 11), and enterprise roadmap.
