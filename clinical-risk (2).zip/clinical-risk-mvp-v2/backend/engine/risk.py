from collections import Counter
from datetime import date
WEIGHTS={"Major":3.0,"Minor":1.5,"Administrative":0.5}

def clamp(x): return max(0.0,min(100.0,x))

def calculate(site_id,deviations,total_visits,as_of=None):
    as_of=as_of or date.today(); ds=[d for d in deviations if d["site_id"]==site_id]
    weighted=sum(WEIGHTS.get(d["severity"],0) for d in ds)
    density=clamp(weighted/max(total_visits,1)*100*2.5)
    ages=[(as_of-date.fromisoformat(d["source_record_date"])).days for d in ds]
    recent14=sum(0 <= age <= 14 for age in ages)
    recent30=sum(0 <= age <= 30 for age in ages)
    recency=clamp(recent14*10+max(0,recent30-recent14)*3)
    counts=Counter(d["rule_id"] for d in ds)
    repetition=clamp(sum(max(0,c-1)*5 for c in counts.values()))
    recent=sum(0 <= age <= 14 for age in ages)
    prior=sum(14 < age <= 28 for age in ages)
    velocity=clamp(50+((recent-prior)/max(total_visits,1)*100)*5) if ds else 0
    score=round(clamp(.35*density+.25*velocity+.20*recency+.20*repetition),1)
    band="Critical" if score>=80 else "High" if score>=60 else "Medium" if score>=35 else "Low"
    drivers=[]
    if density>=50: drivers.append("High severity-weighted deviation density")
    if velocity>=60: drivers.append("Deviation rate is worsening")
    if repetition>=25:
        rule,count=counts.most_common(1)[0]; drivers.append(f"Repeated rule {rule} ({count} occurrences)")
    if recent14>=3: drivers.append(f"{recent14} deviations in the last 14 days")
    return {"site_id":site_id,"score":score,"band":band,
            "components":{"deviation_density":round(density,1),"trend_velocity":round(velocity,1),
                          "recency":round(recency,1),"repetition":round(repetition,1)},
            "drivers":drivers,"as_of":as_of.isoformat()}
