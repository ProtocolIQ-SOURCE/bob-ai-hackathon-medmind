from datetime import date
def parse_date(v): return date.fromisoformat(v)
def visit_window_days(p, vt): return int(p["visits"][vt]["window_days"])
def required_assessments(p, vt): return set(p.get("required_assessments", {}).get(vt, []))
def restricted_medications(p): return {x["name"]: x for x in p.get("restricted_medications", [])}
