from backend.engine.protocol import parse_date, visit_window_days, required_assessments, restricted_medications

class Rule:
    rule_id = ""
    category = ""
    severity = ""
    protocol_clause = ""
    def evaluate(self, visit, protocol): raise NotImplementedError

class VisitWindowRule(Rule):
    rule_id, category, severity = "VISIT-001", "Visit Compliance", "Minor"
    protocol_clause = "Visit schedule and windows"
    def evaluate(self, v, p):
        delta = abs((parse_date(v.actual_date)-parse_date(v.scheduled_date)).days)
        allowed = visit_window_days(p, v.visit_type)
        if delta > allowed:
            return {"expected":f"within ±{allowed} days","actual":f"{delta} days from scheduled date",
                    "threshold":f"±{allowed} days",
                    "explanation":f"Visit occurred {delta} days from scheduled date, exceeding the permitted ±{allowed}-day window."}

class DoseVarianceRule(Rule):
    rule_id, category, severity = "DOS-001", "Dose Compliance", "Major"
    protocol_clause = "Section 5.2 — Study drug dosing"
    def evaluate(self, v, p):
        if v.dose_given_mg is None: return None
        nominal=float(p["dosing"]["nominal_dose_mg"]); tol=float(p["dosing"]["tolerance_percent"])
        variance=(v.dose_given_mg-nominal)/nominal*100
        if abs(variance)>tol:
            return {"expected":f"{nominal:g} mg","actual":f"{v.dose_given_mg:g} mg","threshold":f"±{tol:g}%",
                    "explanation":f"Dose was {variance:+.1f}% from the nominal {nominal:g} mg dose, exceeding the permitted ±{tol:g}% tolerance."}

class ConcomitantMedicationRule(Rule):
    rule_id, category, severity = "MED-001", "Concomitant Medication", "Major"
    protocol_clause = "Section 6.1 — Restricted medications"
    def evaluate(self, v, p):
        hits=[m for m in v.concomitant_meds if m in restricted_medications(p)]
        if hits:
            names=", ".join(hits)
            return {"expected":"No restricted medication","actual":names,"threshold":"Restricted-medication list",
                    "explanation":f"Restricted medication {names} was logged for the visit."}

class RequiredAssessmentRule(Rule):
    rule_id, category, severity = "ASSESS-001", "Required Assessment", "Minor"
    protocol_clause = "Section 7 — Required assessments"
    def evaluate(self, v, p):
        required=required_assessments(p,v.visit_type); missing=sorted(required-set(v.assessments))
        if missing:
            return {"expected":sorted(required),"actual":sorted(v.assessments),
                    "threshold":"All required assessments present",
                    "explanation":f"Required assessment(s) missing: {', '.join(missing)}."}

RULES=[VisitWindowRule(),DoseVarianceRule(),ConcomitantMedicationRule(),RequiredAssessmentRule()]
