from dataclasses import dataclass
from typing import Any

@dataclass(frozen=True)
class Visit:
    patient_id: str
    site_id: str
    visit_id: str
    visit_type: str
    scheduled_date: str
    actual_date: str
    dose_given_mg: float | None
    concomitant_meds: tuple[str, ...] = ()
    assessments: tuple[str, ...] = ()

@dataclass
class Deviation:
    deviation_id: str
    rule_id: str
    patient_id: str
    site_id: str
    visit_id: str
    severity: str
    category: str
    expected: Any
    actual: Any
    threshold: Any
    protocol_clause: str
    explanation: str
    source_record: str
    source_record_date: str
