from flask import Flask,jsonify,request,Response,send_from_directory
import json,queue
from backend.pipeline import Pipeline

app=Flask(__name__,static_folder="../frontend",static_url_path="")
pipeline=Pipeline(); subscribers=[]

def publish(event):
    for q in list(subscribers):
        try:q.put_nowait(event)
        except queue.Full: pass

@app.get("/")
def home(): return send_from_directory(app.static_folder,"index.html")
@app.get("/api/sites")
def sites(): return jsonify(pipeline.sites())
@app.get("/api/sites/<site>/risk")
def risk(site):
    x=pipeline.risk(site); return jsonify(x) if x else (jsonify({"error":"Site not found"}),404)
@app.get("/api/sites/<site>/deviations")
def deviations(site): return jsonify(pipeline.deviations(site))
@app.get("/api/deviations/<id>")
def explain(id):
    x=pipeline.explain(id); return jsonify(x) if x else (jsonify({"error":"Deviation not found"}),404)
@app.post("/api/deviations/<id>/capa")
def capa(id):
    x=pipeline.capa(id); return jsonify(x) if x else (jsonify({"error":"Deviation not found"}),404)
@app.post("/api/visits")
def add_visit():
    pipeline.add_visit(request.get_json(force=True)); publish({"type":"risk.updated","sites":pipeline.sites()})
    return jsonify({"status":"accepted","sites":pipeline.sites()}),201
@app.get("/api/events")
def events():
    q=queue.Queue(maxsize=10); subscribers.append(q)
    def stream():
        try:
            yield "event: connected\ndata: {}\n\n"
            while True:
                e=q.get(); yield f"event: {e['type']}\ndata: {json.dumps(e)}\n\n"
        finally:
            if q in subscribers: subscribers.remove(q)
    return Response(stream(),mimetype="text/event-stream")
if __name__=="__main__": app.run(debug=True,threaded=True)
