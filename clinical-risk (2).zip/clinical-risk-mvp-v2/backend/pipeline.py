import csv, json, yaml
from pathlib import Path
from backend.models import Visit
from backend.db import init_db,count_visits,insert_visit,all_visits,replace_deviations,all_deviations
from backend.engine.rules import RULES
from backend.engine.risk import calculate

ROOT=Path(__file__).resolve().parent

class Pipeline:
    def __init__(self):
        init_db()
        self.protocol=yaml.safe_load((ROOT/"data/protocol.yaml").read_text())
        self.seed()
    def seed(self):
        if count_visits(): return
        with (ROOT/"data/visits.csv").open() as f:
            for r in csv.DictReader(f):
                insert_visit(Visit(r["patient_id"],r["site_id"],r["visit_id"],r["visit_type"],
                    r["scheduled_date"],r["actual_date"],float(r["dose_given_mg"]) if r["dose_given_mg"] else None,
                    tuple(x for x in r["concomitant_meds"].split(";") if x),
                    tuple(x for x in r["assessments"].split(";") if x)))
        self.recalculate()
    def add_visit(self,p):
        insert_visit(Visit(p["patient_id"],p["site_id"],p["visit_id"],p["visit_type"],
            p["scheduled_date"],p["actual_date"],p.get("dose_given_mg"),
            tuple(p.get("concomitant_meds",[])),tuple(p.get("assessments",[]))))
        self.recalculate()
    def recalculate(self):
        rows=[]; n=1
        for r in all_visits():
            v=Visit(r["patient_id"],r["site_id"],r["visit_id"],r["visit_type"],r["scheduled_date"],r["actual_date"],
                    r["dose_given_mg"],tuple(filter(None,r["concomitant_meds"].split(";"))),
                    tuple(filter(None,r["assessments"].split(";"))))
            for rule in RULES:
                x=rule.evaluate(v,self.protocol)
                if x:
                    rows.append((f"DEV-{n:04d}",rule.rule_id,v.patient_id,v.site_id,v.visit_id,rule.severity,
                        rule.category,json.dumps(x["expected"]),json.dumps(x["actual"]),x["threshold"],
                        rule.protocol_clause,x["explanation"],v.visit_id,v.actual_date)); n+=1
        replace_deviations(rows)
    def deviations(self,site=None):
        rows=[dict(r) for r in all_deviations()]
        if site: rows=[r for r in rows if r["site_id"]==site]
        for r in rows: r["expected"]=json.loads(r["expected"]); r["actual"]=json.loads(r["actual"])
        return rows
    def risk(self,site):
        vs=[dict(r) for r in all_visits() if r["site_id"]==site]
        return calculate(site,self.deviations(site),len(vs)) if vs else None
    def sites(self):
        rows=all_visits(); ids=sorted({r["site_id"] for r in rows}); out=[]
        for s in ids:
            ds=self.deviations(s); r=self.risk(s)
            out.append({"site_id":s,"score":r["score"],"band":r["band"],"total_visits":sum(x["site_id"]==s for x in rows),
                        "major_deviations":sum(d["severity"]=="Major" for d in ds),"total_deviations":len(ds)})
        return sorted(out,key=lambda x:x["score"],reverse=True)
    def explain(self,id):
        d=next((x for x in self.deviations() if x["deviation_id"]==id),None)
        if not d:return None
        d["audit_trace"]={"rule":d["rule_id"],"source_record":d["source_record"],"protocol_clause":d["protocol_clause"],
                          "expected":d["expected"],"actual":d["actual"],"threshold":d["threshold"],"result":"FAIL"}
        return d
    def capa(self,id):
        d=self.explain(id)
        if not d:return None
        return {"deviation_summary":d["explanation"],"severity":d["severity"],
                "root_cause_category":"[Site investigation required]",
                "corrective_action":"[Draft with investigator; verify against source records]",
                "preventive_action":"[Draft with investigator; define effectiveness check]",
                "owner":"[Assign owner]","target_date":"[Assign target date]",
                "protocol_clause":d["protocol_clause"],"source_record":d["source_record"]}
