import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).resolve().parents[1] / "clinical_risk.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS visits (
  patient_id TEXT NOT NULL,
  site_id TEXT NOT NULL,
  visit_id TEXT PRIMARY KEY,
  visit_type TEXT NOT NULL,
  scheduled_date TEXT NOT NULL,
  actual_date TEXT NOT NULL,
  dose_given_mg REAL,
  concomitant_meds TEXT NOT NULL,
  assessments TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS deviations (
  deviation_id TEXT PRIMARY KEY,
  rule_id TEXT NOT NULL,
  patient_id TEXT NOT NULL,
  site_id TEXT NOT NULL,
  visit_id TEXT NOT NULL,
  severity TEXT NOT NULL,
  category TEXT NOT NULL,
  expected TEXT NOT NULL,
  actual TEXT NOT NULL,
  threshold TEXT NOT NULL,
  protocol_clause TEXT NOT NULL,
  explanation TEXT NOT NULL,
  source_record TEXT NOT NULL,
  source_record_date TEXT NOT NULL
);
"""

def connect():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    with connect() as c:
        c.executescript(SCHEMA)

def count_visits():
    with connect() as c:
        return c.execute("SELECT COUNT(*) FROM visits").fetchone()[0]

def insert_visit(v):
    with connect() as c:
        c.execute("INSERT OR REPLACE INTO visits VALUES (?,?,?,?,?,?,?,?,?)",
                  (v.patient_id,v.site_id,v.visit_id,v.visit_type,v.scheduled_date,
                   v.actual_date,v.dose_given_mg,";".join(v.concomitant_meds),";".join(v.assessments)))

def all_visits():
    with connect() as c:
        return c.execute("SELECT * FROM visits ORDER BY actual_date, visit_id").fetchall()

def replace_deviations(rows):
    with connect() as c:
        c.execute("DELETE FROM deviations")
        c.executemany("INSERT INTO deviations VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)

def all_deviations():
    with connect() as c:
        return c.execute("SELECT * FROM deviations ORDER BY source_record_date, deviation_id").fetchall()
