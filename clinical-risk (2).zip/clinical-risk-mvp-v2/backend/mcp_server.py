"""MCP server for the deterministic clinical-trial risk monitor.

Bob is the MCP client. The tools below expose read-only risk/deviation data and
fact-grounded CAPA scaffolding; they never decide whether a deviation exists.
"""
from typing import Optional

from mcp.server.fastmcp import FastMCP

from backend.pipeline import Pipeline

mcp = FastMCP(
    "clinical-risk-monitor",
    instructions=(
        "Clinical trial risk monitor. Deviation detection, severity and risk are "
        "deterministic. Treat tool outputs as authoritative facts from the rule engine. "
        "Do not invent deviations or change their severity. CAPA root causes and actions "
        "are drafts requiring investigator verification."
    ),
    json_response=True,
)

pipeline = Pipeline()


@mcp.tool()
def get_site_risk(site_id: str) -> dict:
    """Return the deterministic risk score, components, and drivers for a site."""
    result = pipeline.risk(site_id)
    return result or {"error": "Site not found", "site_id": site_id}


@mcp.tool()
def list_deviations(site_id: str, severity: Optional[str] = None) -> list[dict]:
    """List deviations already identified by the deterministic rule engine."""
    rows = pipeline.deviations(site_id)
    if severity:
        rows = [r for r in rows if r["severity"].lower() == severity.lower()]
    return rows


@mcp.tool()
def explain_deviation(deviation_id: str) -> dict:
    """Explain a deviation with its exact rule, record, threshold, and protocol clause."""
    result = pipeline.explain(deviation_id)
    return result or {"error": "Deviation not found", "deviation_id": deviation_id}


@mcp.tool()
def compare_sites(site_ids: Optional[list[str]] = None) -> list[dict]:
    """Compare deterministic site risk scores; optionally restrict to selected sites."""
    rows = pipeline.sites()
    return [r for r in rows if not site_ids or r["site_id"] in site_ids]


@mcp.tool()
def generate_capa_report(deviation_id: str) -> dict:
    """Generate a fact-grounded CAPA draft; root cause and actions remain investigator placeholders."""
    result = pipeline.capa(deviation_id)
    return result or {"error": "Deviation not found", "deviation_id": deviation_id}


if __name__ == "__main__":
    mcp.run(transport="stdio")
