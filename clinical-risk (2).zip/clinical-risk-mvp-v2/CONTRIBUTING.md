# Contributing & Submission Guidelines

This repository is structured according to the official **Bob AI Hackathon Submission Template**.

## Submission Rules

1. **Do not modify** `.github/workflows/validate.yml` — it runs automated checks on your submission.
2. **Keep all required files** in their expected locations:
   - `submission.yaml` (metadata filled out completely)
   - `README.md` (project overview without empty bracket placeholders)
   - `docs/problem-statement.md`
   - `docs/solution-overview.md`
   - `docs/architecture.md`
   - `docs/setup-guide.md`
   - `demo/demo-video-link.txt`
   - `demo/live-demo-url.txt`
   - `demo/screenshots/` (at least 3 screenshots)
   - `presentation/slides.pdf` or `presentation/slides.pptx`
3. **Keep credentials private**: Never commit `.env` files or secret keys. All variable templates belong in `src/.env.example`.
4. **Source code goes in `src/`**: All backend and frontend code must be maintained within `src/`.
5. **Ensure GitHub Action is green**: Before submitting, verify that the `Validate Submission` action passes.

## Development Workflow

1. Create a virtual environment and install dependencies:
   ```bash
   python -m venv .venv
   source .venv/bin/activate  # Or on Windows: .venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   ```
2. Run automated test suite:
   ```bash
   pytest -q
   ```
3. Start the application locally:
   ```bash
   python -m backend.app
   ```
   Open `http://127.0.0.1:5000` in your browser.
