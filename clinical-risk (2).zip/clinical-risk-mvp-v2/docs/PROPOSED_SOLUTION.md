# Proposed Solution

## TrialGuard

TrialGuard is a clinical trial risk monitor that combines a deterministic protocol rule engine, site-level risk scoring, a lightweight Flask API, and an investigation workspace for Bob.

## How It Works

1. Visit records are stored locally in SQLite.
2. Protocol rules evaluate dosing, visit timing, and assessment completeness.
3. Detected deviations receive an operational severity and an explainable trace.
4. The risk engine combines deviation density, velocity, recency, and repetition into a 0-100 site score.
5. The dashboard presents site risk, drivers, deviations, activity, and CAPA review context.
6. New visits can be posted through the API and published to connected dashboard clients.

## Responsible AI Boundary

The rule and risk engines remain deterministic and are the source of truth for facts. Bob can help investigate and draft CAPA language, but it does not decide whether a deviation exists or approve a quality action. Human review is required for clinical, quality, and regulatory decisions.

## Technology

- Python and Flask
- SQLite
- Dependency-light HTML, CSS, and JavaScript dashboard
- MCP server for read-only investigation tools and fact-grounded CAPA scaffolding
- Pytest for automated checks