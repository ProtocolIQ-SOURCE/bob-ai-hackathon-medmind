# Problem Statement

## Who Is Affected

Clinical operations teams oversee visits and protocol adherence across many study sites. Clinical data managers and quality teams investigate deviations, while site quality staff must document corrective and preventive actions. Study leaders also need to compare sites and decide where limited monitoring and investigation capacity should go first.

These users often work across visit records, protocol documents, spreadsheets, and separate operational systems. A deviation may be visible in one record but its relationship to other deviations, site history, or protocol expectations is not obvious.

## The Core Problem

The practical problem is not simply detecting an incorrect dose or a late visit. It is connecting an operational signal to an auditable explanation and an appropriate level of site attention. Teams need to know:

- What happened and which source record supports it?
- Which protocol rule or clause defines the expected behavior?
- Is this an isolated event or part of a repeated site pattern?
- Which site needs attention first, and why?
- What should an investigator review before drafting a CAPA?

Without that connection, risk review becomes a manual reconciliation exercise. Important signals can be found late, discussed without a consistent evidence trail, or prioritized by intuition rather than comparable criteria.

## Why Existing Approaches Fall Short

Basic spreadsheets can list deviations, but they do not reliably recalculate site-level risk as new visits arrive or preserve a consistent rule trace across reviewers. A simple dashboard with red, amber, and green labels is faster to scan, but a score without evidence does not answer the investigator's next question: "Why is this site risky?"

A purely generative assistant creates a different problem. It may summarize records fluently, but it should not be trusted to decide whether a protocol deviation exists or to invent a protocol threshold. That boundary is especially important for clinical, quality, and regulatory workflows.

TrialGuard addresses the gap by keeping fact detection and scoring deterministic, then using Bob as an investigation and drafting interface around those facts.

## Quantified Pain and Prototype Evidence

No validated external time, error-rate, or cost study is included in this prototype, so TrialGuard does not claim a specific reduction in monitoring cost or investigation time. The bundled synthetic demonstration dataset contains 19 detected deviations for SITE-C and produces a site risk score of 95/100, compared with 0/100 for SITE-A and SITE-B. These values demonstrate prioritization and explainability behavior; they are not production performance measurements.

A production evaluation should measure time from visit availability to deviation review, time from deviation to CAPA draft, missed-deviation rate, false-positive review rate, and reviewer agreement before and after adoption.

## Why This Matters Now

Clinical studies are becoming more distributed and data-rich while quality teams are expected to identify risk earlier and document decisions more consistently. Generative AI makes conversational investigation possible, but adoption requires a trustworthy source of facts and a clear human-approval boundary. A deterministic evidence layer paired with an assistant is therefore more useful than an opaque risk label or an ungrounded chatbot.

## Desired Outcome

Study teams should be able to move from portfolio view to site, deviation, evidence, and next investigation step in one workflow. The system should make priority visible, make the reason inspectable, and leave clinical and quality decisions with qualified people.
