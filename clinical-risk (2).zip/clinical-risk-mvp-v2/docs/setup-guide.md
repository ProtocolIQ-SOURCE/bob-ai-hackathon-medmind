# Setup Guide

## Prerequisites

- Python 3.11 or newer
- PowerShell, Command Prompt, or a Unix-compatible shell

## Install and Run

From the repository root, run:

```bash
python -m venv .venv
python -m pip install -r requirements.txt
python -m pytest -q
python -m backend.app
```

Open the dashboard at http://127.0.0.1:5000.

On Windows PowerShell, activate the environment before installation if desired:

```powershell
.venv\Scripts\Activate.ps1
```

On macOS or Linux, activate it with:

```bash
source .venv/bin/activate
```

## Optional Bob MCP Setup

Open the repository in IBM Bob, enable MCP servers, and confirm the `clinical-risk-monitor` server from `.bob/mcp.json` is enabled. The MCP server runs locally over STDIO and uses the same SQLite demo data as the dashboard.