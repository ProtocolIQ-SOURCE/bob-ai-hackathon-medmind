# Problem Statement

## Context

Clinical trial teams monitor visits, dosing, assessments, and protocol timing across multiple sites. Important deviations can be buried in spreadsheets and disconnected operational systems, making it difficult to identify site risk early and explain why a site needs attention.

## Problem

Study teams need a fast, auditable way to detect protocol deviations, rank site risk, and move from a signal to an investigation. A useful solution must show the source record, the rule that fired, the expected versus actual value, and the relevant protocol clause. It must support human review rather than replacing clinical or quality decisions.

## Users

- Clinical operations teams monitoring study sites
- Clinical data and quality teams investigating deviations
- Site quality teams preparing corrective and preventive actions
- Study leaders comparing risk across a portfolio

## Success Criteria

- Surface the highest-risk sites at a glance.
- Explain every detected deviation with deterministic evidence.
- Support a repeatable investigation and CAPA workflow.
- Accept a new visit and refresh the risk picture quickly.
- Keep the source of truth auditable and separate from generated prose.