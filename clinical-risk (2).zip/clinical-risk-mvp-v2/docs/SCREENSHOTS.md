# Screenshots

Capture these views from the running dashboard for the final submission:

1. Overview showing the site risk scoreboard and portfolio risk.
2. Deviation Log showing rule, expected value, actual value, and protocol clause.
3. CAPA Workspace showing the fact-grounded review scaffold.
4. Bob Investigation Desk showing an investigation prompt and response.
5. Updated Overview after posting the sample incoming visit.

Recommended filenames:

```text
docs/screenshots/01-overview.png
docs/screenshots/02-deviation-log.png
docs/screenshots/03-capa-workspace.png
docs/screenshots/04-bob-investigation.png
docs/screenshots/05-live-update.png
```

The screenshots must use synthetic data only. Do not capture identifiable patient information or local credentials.