# Demo Guide

## Start

From the repository root:

```bash
python -m venv .venv
python -m pip install -r requirements.txt
python -m backend.app
```

Open http://127.0.0.1:5000.

## Five-Minute Walkthrough

1. Open Overview and point out the site scoreboard, portfolio risk, and live activity.
2. Show that SITE-C is the highest-risk site and identify its visible deviation signals.
3. Open Deviation Log and trace a deviation to its expected value, actual value, and protocol clause.
4. Open CAPA and explain that the draft is a review scaffold, not an approved action.
5. Open Bob Copilot and ask:

   ```text
   Show me the highest-risk site and explain the top driver.
   ```

6. Simulate an incoming visit:

   ```bash
   curl -X POST http://127.0.0.1:5000/api/visits ^
     -H "Content-Type: application/json" ^
     -d "{\"patient_id\":\"P-305\",\"site_id\":\"SITE-C\",\"visit_id\":\"V-3011\",\"visit_type\":\"week_4\",\"scheduled_date\":\"2026-09-05\",\"actual_date\":\"2026-09-08\",\"dose_given_mg\":130,\"concomitant_meds\":[],\"assessments\":[\"vitals\",\"labs\"]}"
   ```

7. Refresh the dashboard and show the updated local risk data.

## Demo Data Note

The bundled data is synthetic demonstration data. The application is not connected to a live clinical system and must not be used with identifiable patient data.