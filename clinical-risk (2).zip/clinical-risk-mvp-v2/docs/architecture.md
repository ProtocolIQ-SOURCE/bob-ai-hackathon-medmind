# System Architecture: TrialGuard

TrialGuard is an explainable clinical trial risk monitor designed to detect protocol deviations deterministically, aggregate site-level risk transparently, and empower study teams through interactive dashboards and an IBM Bob MCP investigation copilot.

---

## 1. System Architecture Diagram

```mermaid
graph TD
    subgraph ClientLayer ["Client & Interaction Layer"]
        UI["Web Browser Dashboard<br/>(HTML5 / CSS / Vanilla JS / SSE)"]
        BobCLI["IBM Bob / MCP Client<br/>(CLI & Agent Workspace)"]
    end

    subgraph ServiceLayer ["Application & Intelligence Services"]
        FlaskServer["Flask Application Server<br/>(REST Endpoints & SSE Broker)"]
        MCPServer["TrialGuard MCP Server<br/>(FastMCP / stdio)"]
    end

    subgraph CoreEngine ["Deterministic Risk & Rule Engines"]
        RuleEngine["Protocol Rule Engine<br/>(Dosing, Timing, Assessment Checks)"]
        RiskEngine["Site Risk Calculator<br/>(Density, Velocity, Recency, Repetition)"]
        CAPAEngine["CAPA Scaffolding Engine<br/>(Evidence-Grounded Action Drafts)"]
    end

    subgraph StorageLayer ["Data & Protocol Persistence"]
        DB[(SQLite Database<br/>clinical_risk.db)]
        ProtocolConfig["Protocol Rules Definition<br/>(backend/data/protocol.yaml)"]
        VisitData["Raw / Synthetic Visit Stream<br/>(visits.csv & POST /api/visits)"]
    end

    %% Client Interactions
    UI -->|HTTP GET /api/sites, /api/deviations| FlaskServer
    UI -->|SSE Stream /api/events| FlaskServer
    BobCLI -->|Tool Calls (stdio)| MCPServer

    %% Application Server Interactions
    FlaskServer -->|Query & Ingest| DB
    FlaskServer -->|Evaluate Incoming Visits| RuleEngine
    FlaskServer -->|Calculate Scores| RiskEngine

    %% MCP Server Interactions
    MCPServer -->|Read-only Queries & Risk Scoring| CoreEngine
    MCPServer -->|Trace Grounded Facts| DB

    %% Core Engine Interactions
    RuleEngine -->|Load Rules & Tolerances| ProtocolConfig
    RuleEngine -->|Store Detected Deviations| DB
    RiskEngine -->|Aggregate Deviation Signals| DB
    CAPAEngine -->|Derive Root Cause Scaffolds| DB
    VisitData -->|Batch / Live Simulation| DB
```

---

## 2. Component Table

| Component | Technology | Responsibility |
| :--- | :--- | :--- |
| **Web Dashboard** | HTML5, CSS3, Vanilla JavaScript, Server-Sent Events (SSE) | Renders responsive site scoreboards, portfolio risk distributions, sortable deviation logs, CAPA review workspace, and live event notifications. |
| **Application Server** | Python 3.11+, Flask | Exposes REST APIs (`/api/sites`, `/api/deviations`, `/api/visits`, `/api/deviations/<id>/capa`) and provides an SSE message queue for live browser updates. |
| **Protocol Rule Engine** | Python (`backend.engine.rules`, `backend.engine.protocol`) | Evaluates patient visit records against formal protocol rules (dosing tolerance, visit window schedule, required assessments) to deterministically identify deviations. |
| **Risk Scoring Engine** | Python (`backend.engine.risk`) | Calculates transparent 0–100 site risk scores based on four mathematically grounded dimensions: deviation density, trend velocity, recency, and repetition. |
| **CAPA Scaffolding Engine** | Python (`backend.pipeline`) | Generates structured Corrective and Preventive Action (CAPA) templates directly linked to verifiable audit traces and protocol clauses. |
| **IBM Bob MCP Server** | Python, Model Context Protocol (`FastMCP`) | Exposes specialized tools (`get_site_risk`, `list_deviations`, `explain_deviation`, `compare_sites`, `generate_capa_report`) over stdio for conversational investigation by IBM Bob. |
| **Persistence Layer** | SQLite (`clinical_risk.db`) | Stores normalized tables for study sites, patient visit records, deviation logs with audit trails, and review statuses. |
| **Protocol Configuration** | YAML (`backend/data/protocol.yaml`) | Defines protocol rules, schedule windows, allowed dosing margins, and severity levels in human- and machine-readable format. |

---

## 3. End-to-End Data Flow

### A. Ingestion & Rule Evaluation
1. **Visit Ingestion**: Synthetic visit records are loaded at bootstrap or streamed via `POST /api/visits`.
2. **Rule Verification**: Each record is inspected by the Protocol Rule Engine against `protocol.yaml`:
   - **Dosing (`DOS-001`)**: Compares administered dose against prescribed amount (tolerance: ±10%).
   - **Timing (`WIN-001`)**: Evaluates visit date versus scheduled target window (tolerance: ±3 days).
   - **Assessments (`ASM-001`)**: Validates that all protocol-mandated evaluations (e.g. vitals, ECG, labs) were conducted.
3. **Audit Trail Recording**: When a rule is violated, a deviation record is inserted into SQLite containing:
   - Rule ID and severity classification (Minor, Moderate, Major, Critical).
   - Traceable expected vs. actual parameters and rule threshold.
   - Reference to the governing protocol clause.

### B. Risk Aggregation & Scoring
1. For each study site, the Risk Engine gathers historical and active deviation records.
2. The aggregate score ($0 - 100$) is computed from 4 weighted components:
   - **Deviation Density**: Number of deviations normalized by patient population.
   - **Trend Velocity**: Acceleration of new deviations over recent monitoring intervals.
   - **Recency Penalty**: Time decay function emphasizing active risks.
   - **Repetition Multiplier**: Escalation factor for repeated occurrences of the same failure mode.
3. The resulting score and breakdown are stored and prepared for immediate consumption.

### C. Live Real-Time Dashboard Updates
1. Upon ingestion of new visit data, the Flask backend broadcasts a `risk.updated` event to the SSE channel `/api/events`.
2. Connected dashboard clients automatically refresh their site scorecards, deviation feeds, and trend charts without full-page reloads.

### D. IBM Bob Copilot & MCP Tool Integration
1. The user prompts IBM Bob (e.g., *"Which site is at highest risk and why?"*).
2. IBM Bob executes the `get_site_risk` or `explain_deviation` MCP tool over `stdio`.
3. The MCP server queries the deterministic pipeline and returns exact, factual figures (e.g., SITE-C score 82, primary driver: DOS-001 dosing deviation on patient P-305).
4. IBM Bob synthesizes an explainable investigation summary strictly anchored in the underlying audit data.

---

## 4. Security, Data Privacy & Scalability Notes

### Data Privacy & Compliance (GxP / HIPAA)
- **Synthetic Data Baseline**: The demonstration environment exclusively operates on synthetic clinical records with non-identifiable subject identifiers (`P-101`, `P-305`).
- **Audit Trace Integrity**: Every risk score and deviation flag retains an unalterable audit trace pointing to source record fields, satisfying 21 CFR Part 11 traceability principles.
- **Responsible AI Boundary**: AI is strictly employed for conversational exploration and draft scaffolding. Rule evaluation and risk scoring remain 100% deterministic code. No generative model can override a protocol violation flag or close a deviation.

### Scalability Considerations
- **Stateless MCP Execution**: The MCP server operates as a lightweight CLI / stdio bridge, allowing concurrent evaluation sessions without state collision.
- **Modular Storage**: While SQLite is ideal for portable zero-dependency evaluation, the database abstraction layer (`backend.db`) uses standard SQL constructs easily portable to PostgreSQL or IBM Cloud Databases for DB2 in enterprise deployments.
- **Event-Driven Architecture**: The Server-Sent Events (SSE) stream decoupled visit processing from frontend polling, reducing redundant database queries.
