# Solution Overview

## TrialGuard in One Sentence

TrialGuard turns structured clinical-trial visit records into deterministic deviation evidence, a comparable site-risk signal, and a guided investigation workflow for study teams.

## Core Mechanism

The solution has four connected layers:

1. **Protocol evaluation:** Visit records are stored in SQLite and evaluated against explicit protocol rules for dosing, visit timing, and assessment completeness. A rule either produces a deviation or does not; the engine does not ask a language model to make that factual decision.
2. **Evidence trace:** Each deviation retains the source record, rule identifier, expected value, actual value, threshold, severity, and protocol clause. This makes the result inspectable instead of presenting only a label.
3. **Site risk scoring:** The risk engine aggregates deviation density, trend velocity, recency, and repetition into a deterministic 0-100 score. The score helps prioritize sites while the underlying deviations explain it.
4. **Investigation interface:** The Flask dashboard exposes the portfolio, site, deviation, live activity, and CAPA views. IBM Bob MCP tools provide read-only investigation functions and a fact-grounded CAPA scaffold around the same source facts.

A new visit can be posted through the REST API. The pipeline persists it, reruns the rules and risk calculation, and publishes an SSE update for connected dashboard clients.

## What Makes It Different

A naive implementation would either show a static deviation table or send raw records directly to a chatbot and ask it to identify risk. TrialGuard separates those responsibilities:

- The deterministic engine decides whether a deviation exists.
- The risk engine applies consistent prioritization logic.
- The evidence trace shows how the decision was reached.
- Bob helps a person investigate and draft, but does not become the system of record.

This design makes the assistant useful without requiring the evaluator to trust unsupported generated claims. It also lets a reviewer challenge a rule, threshold, or source record directly.

## Key Design Decisions

### Deterministic rules for protocol facts

Protocol adherence is a high-consequence workflow. Explicit rules are easier to test, audit, version, and explain than an unconstrained model judgment.

### A composite score instead of a single count

Counting deviations alone can over-prioritize a site with one old issue or under-prioritize a site whose issues are accelerating. Density, velocity, recency, and repetition provide a more useful operational signal while remaining understandable.

### Evidence-first data contracts

The API and MCP tools return structured facts such as rule IDs, expected and actual values, thresholds, and protocol clauses. This supports consistent dashboard rendering and gives Bob grounded material for investigation.

### Human review at the decision boundary

CAPA content is presented as a scaffold with investigator placeholders. The workflow deliberately stops short of approving a root cause, impact assessment, owner, or due date.

### Dependency-light delivery

The dashboard is plain HTML, CSS, and JavaScript served by Flask. This keeps the MVP easy to run for a demonstration and makes the core behavior visible without a large frontend build system.

## User Experience

A study lead opens the Overview page and immediately sees monitored sites, the highest score, open deviations, and portfolio distribution. Selecting the deviation view exposes the severity, site, rule, expected value, actual value, and protocol clause. The investigator can then move to CAPA for a review scaffold or open Bob Copilot to ask for a site explanation, a deviation trace, a comparison, or a draft report.

When a new visit is submitted, the local pipeline recalculates the affected site and the dashboard can refresh its live activity. The user remains able to inspect the event that changed the score rather than receiving an unexplained notification.

## Prototype Boundary

The current implementation uses synthetic demonstration data and a local SQLite database. It does not connect to live clinical systems, provide production identity and access controls, or claim GxP validation. Those are deliberate next steps for a production implementation, not capabilities implied by this MVP.
