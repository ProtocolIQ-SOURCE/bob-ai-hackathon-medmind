# Source Code (`src/`)

This directory contains the entire source code for **TrialGuard**, organized as a monorepo containing backend services, protocol engines, and frontend assets.

## Directory Layout

```
src/
├── backend/                  # Python backend application & services
│   ├── app.py                # Flask server, REST API endpoints, and SSE stream
│   ├── db.py                 # SQLite schema initialization and query operations
│   ├── mcp_server.py         # IBM Bob Model Context Protocol (MCP) server
│   ├── models.py             # Data dataclasses for visits and deviations
│   ├── pipeline.py           # Core business logic orchestrating risk and deviations
│   ├── data/                 # Protocol rules definition (YAML) and synthetic visits (CSV)
│   │   ├── protocol.yaml     # Study protocol limits, dosing tolerances, and windows
│   │   └── visits.csv        # Baseline synthetic study visit records
│   └── engine/               # Deterministic rule & risk scoring algorithms
│       ├── protocol.py       # Protocol configuration loader and validator
│       ├── risk.py           # Multi-factor explainable 0–100 site risk algorithm
│       └── rules.py          # Deterministic dosing, timing, and assessment checks
├── frontend/                 # Client dashboard interface
│   └── index.html            # Responsive single-page application (HTML5, CSS, JS)
├── .env.example              # Template for environment variables
└── README.md                 # This layout documentation
```

## Architecture Summary

- **Backend**: Implemented in Python 3 using Flask for REST/SSE endpoints. It runs deterministic protocol compliance checks against clinical visit records and exposes an MCP server for IBM Bob copilot queries.
- **Frontend**: A zero-dependency, mobile-responsive web dashboard that renders real-time site scorecards, deviation audit logs, and CAPA workspaces with live updates via Server-Sent Events (SSE).
- **Persistence**: Local SQLite database storing normalized visits, calculated deviations, and risk metrics.
