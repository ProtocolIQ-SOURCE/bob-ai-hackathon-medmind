# TrialGuard: Explainable Clinical Trial Risk Monitor

TrialGuard is a deterministic clinical-trial risk monitor with a responsive dashboard, explainable deviation detection, site-level scoring, and IBM Bob investigation tools.

## Team

- **Team:** MedMinds
- **Track:** AI
- **Lead:** Rahi Pandya, rahi.pandya@ibm.com
- **Member:** Bob Singh, bob.singh@ibm.com

## Problem Statement

Clinical trial teams can miss protocol deviations when visit, dosing, assessment, and timing data are spread across operational records. This delays investigation, makes site risk difficult to compare, and leaves teams without a clear evidence trail from a risk signal to a source record.

## Solution

TrialGuard evaluates synthetic visit records with deterministic protocol rules, stores the results in SQLite, and calculates an explainable 0–100 risk score for each site. Its Flask dashboard shows the evidence, while IBM Bob MCP tools support investigation, site comparison, and fact-grounded CAPA drafting without replacing human quality decisions.

## Key Features

- Deterministic detection of dosing, visit-timing, and assessment deviations.
- Explainable site risk scoring using deviation density, velocity, recency, and repetition.
- Dashboard views for portfolio risk, site risk, deviation evidence, live activity, and CAPA review.
- IBM Bob MCP tools for risk lookup, deviation explanation, site comparison, and CAPA scaffolding.
- REST and SSE support for simulating incoming visits and dashboard updates.

## Tech Stack

- **Language:** Python, HTML, CSS, JavaScript
- **Backend:** Flask
- **Persistence:** SQLite
- **Testing:** pytest
- **IBM technologies:** IBM Bob integration through MCP and the project-level `.bob/mcp.json` configuration
- **Frontend:** Dependency-free responsive web dashboard served by Flask

## How to Run

Follow `docs/setup-guide.md`. The exact core commands are:

```bash
python -m venv .venv
python -m pip install -r requirements.txt
python -m pytest -q
python -m backend.app
```

Open http://127.0.0.1:5000.

## Demo

- **Local demo:** http://127.0.0.1:5000 (status: `demo/live-demo-url.txt`)
- **Demo video:** `demo/demo-video-link.txt`
- **Screenshots:** `demo/screenshots/`
- **Demo walkthrough:** `demo/README.md` and `docs/DEMO.md`
- **Presentation slides:** `presentation/slides.pdf` and `presentation/slides.pptx`

## Documentation

- **Problem statement:** `docs/problem-statement.md`
- **Solution overview:** `docs/solution-overview.md`
- **Technical architecture:** `docs/architecture.md`
- **Setup guide:** `docs/setup-guide.md`
- **Source layout:** `src/README.md`
- **Submission metadata:** `submission.yaml`
- **Submission validation:** `.github/workflows/validate.yml`

## Known Limitations

- The bundled visits and risk data are synthetic demonstration data, not live clinical data.
- The application has no production authentication, authorization, encryption, or external clinical-system connector.
- The browser Bob panel is a local scripted demo; the separate MCP server provides the tool integration boundary.
- Risk rules and protocol configuration are prototype-level and are not validated for GxP production use.
- Screenshots and demo links are local repository artifacts until the project is published and a recording is created.

## What We Are Most Proud Of

The strongest part of TrialGuard is the evidence-first path from a site score to an explainable deviation: each signal can be traced to a rule, source record, expected value, actual value, threshold, and protocol clause. The dashboard and Bob MCP tools make that same deterministic evidence usable in both rapid operational monitoring and structured investigation.

## License and Safety Note

This is a hackathon prototype, not a validated GxP production system. Use synthetic data only and require qualified human review for clinical, quality, and regulatory decisions.
