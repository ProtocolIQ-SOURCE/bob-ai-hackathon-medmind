from backend.pipeline import Pipeline

def test_sites_exist():
    p=Pipeline()
    assert {x["site_id"] for x in p.sites()}=={"SITE-A","SITE-B","SITE-C"}

def test_rule_and_trace():
    p=Pipeline()
    d=next(x for x in p.deviations("SITE-C") if x["rule_id"]=="DOS-001")
    x=p.explain(d["deviation_id"])
    assert x["severity"]=="Major"
    assert x["audit_trace"]["result"]=="FAIL"
    assert x["audit_trace"]["threshold"]=="±10%"

def test_risk_components():
    r=Pipeline().risk("SITE-C")
    assert 0<=r["score"]<=100
    assert set(r["components"])=={"deviation_density","trend_velocity","recency","repetition"}
