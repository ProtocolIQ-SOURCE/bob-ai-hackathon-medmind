import pytest

def test_mcp_module_exposes_expected_tools():
    pytest.importorskip("mcp")
    from backend.mcp_server import mcp
    names = {tool.name for tool in mcp._tool_manager.list_tools()}
    assert {
        "get_site_risk", "list_deviations", "explain_deviation",
        "compare_sites", "generate_capa_report",
    } <= names
