# Application Screenshots

This directory contains screenshots of the running TrialGuard application:

1. **`01-overview.png`**: Portfolio overview showing site risk scoreboard, risk distribution, and summary metrics.
2. **`02-deviation-log.png`**: Traceable deviation log detailing individual protocol deviations, expected vs. actual values, and protocol clauses.
3. **`03-capa-workspace.png`**: CAPA workspace showing fact-grounded corrective and preventive action drafting.
4. **`04-bob-investigation.png`**: IBM Bob conversational copilot demonstrating AI investigation using MCP tools.
5. **`05-live-update.png`**: Live real-time dashboard update upon receiving simulated incoming visit data over Server-Sent Events.
