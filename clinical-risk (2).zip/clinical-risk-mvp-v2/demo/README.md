# TrialGuard Demo & Artifacts

This folder contains the demo artifacts for evaluating TrialGuard.

## Contents

- **`demo-video-link.txt`**: Link to the recorded video walkthrough demonstration.
- **`live-demo-url.txt`**: Deployment status (set to `NOT DEPLOYED` for local review).
- **`screenshots/`**: High-resolution screenshots showcasing core application views and user flows.

## Running the Demo Locally

1. Set up and start the application:
   ```bash
   python -m venv .venv
   source .venv/bin/activate  # Or on Windows: .venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   python -m backend.app
   ```
2. Open the dashboard at `http://127.0.0.1:5000`.

## 5-Minute Evaluation Walkthrough

1. **Portfolio Overview**: View the site risk scoreboard and observe why SITE-C is flagged as the highest risk study site.
2. **Deviation Log**: Inspect individual protocol deviation records, drilling down into expected vs. actual parameters and rule evidence.
3. **CAPA Workspace**: Review fact-grounded CAPA scaffolding derived deterministically from audit data.
4. **IBM Bob Copilot**: Query site risks or compare sites via the MCP interface.
5. **Real-time Ingestion**: Simulate an incoming visit via `POST /api/visits` and witness the live dashboard update via Server-Sent Events (SSE).
